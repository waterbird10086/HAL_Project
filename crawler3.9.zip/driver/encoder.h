#ifndef __ENCODER_H__
#define __ENCODER_H__

#include "main.h"

float Read_EncoderA(void);
float Read_EncoderB(void);

float Read_SPEEDA(void);
float Read_SPEEDB(void);

#endif

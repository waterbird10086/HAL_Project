#ifndef __PWM_MOTOR_H__
#define __PWM_MOTOR_H__

#include "main.h"

void PWM8_SetCH1(uint16_t Compare);
void PWM8_SetCH2(uint16_t Compare);

#endif

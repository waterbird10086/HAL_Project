#ifndef __IIC_H
#define __IIC_H

void PCA_Init(void);

#endif

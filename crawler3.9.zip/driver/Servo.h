#ifndef __SERVO_H__
#define __SERVO_H__

#include "main.h"

void Servo1_SetAngle(float Angle1);
void Servo2_SetAngle(float Angle2);
void Servo3_SetAngle(float Angle3);
void Servo4_SetAngle(float Angle1);
void PS2Servo(void);

#endif
